var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["848314f8-d7dc-4755-a4a1-3782173096b1","26b80e63-bc0f-408d-b288-be2282aebd4e","dfc53be7-786c-4305-b8eb-81fa595e9903","47fade86-5bd1-4789-87af-896fb1433a7b","043deebf-64b8-4795-be8d-db5055414f2f","c26b6449-0b6c-4483-8486-107c0091c26e","3221caad-ae37-4eec-92a8-56bae4769e66","c4e310e0-8174-4127-a46e-0cbcc94b488b","102dacfe-c65e-4395-8965-8956939facd7","70a55409-907a-431f-85ac-c9f61cf6397b","7552fbc5-56ad-42cc-b172-2b128f545c16","2d207d44-84d0-42d2-b8a7-21ab2a1debd2","672779ce-0acc-4286-b18e-157ee8a14585","22d01de8-2028-4e2b-b9fd-39bd545b2a8e","fd4e8157-ed28-495b-8dc7-89a185b599a4","05eb5005-059e-4051-811c-e667a53783bc","404d85ea-48c5-4058-a13e-be40ca758716","9d52c37c-05c8-4604-8fb4-86158c49ceed","3cf76be0-ab3f-4f7f-82b4-c9c420b029db","e74f6250-bc30-4a10-a68b-7fa22987d7e4","9cd11998-6b06-4311-bab8-48140fca5ed6","c6bbbdea-d7f7-43a0-bf3e-872b9bd46b56","ddb5fb82-9d7c-4f44-b92e-10659ab0e343"],"propsByKey":{"848314f8-d7dc-4755-a4a1-3782173096b1":{"name":"hero","sourceUrl":null,"frameSize":{"x":30,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"zbeCAU8aFpsXcLqDHOEPEckYh9.x7pGW","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":30,"y":30},"rootRelativePath":"assets/848314f8-d7dc-4755-a4a1-3782173096b1.png"},"26b80e63-bc0f-408d-b288-be2282aebd4e":{"name":"enemy1","sourceUrl":null,"frameSize":{"x":35,"y":50},"frameCount":1,"looping":true,"frameDelay":12,"version":"zTNoMh6GiK_uMb0BavoRxbsaHO0TVHOH","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":35,"y":50},"rootRelativePath":"assets/26b80e63-bc0f-408d-b288-be2282aebd4e.png"},"dfc53be7-786c-4305-b8eb-81fa595e9903":{"name":"enemy","sourceUrl":"assets/api/v1/animation-library/gamelab/xasculQGiYxBV79ltD_0E79ZRIexdPdZ/category_food/american_hamburger.png","frameSize":{"x":320,"y":254},"frameCount":1,"looping":true,"frameDelay":2,"version":"xasculQGiYxBV79ltD_0E79ZRIexdPdZ","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":320,"y":254},"rootRelativePath":"assets/api/v1/animation-library/gamelab/xasculQGiYxBV79ltD_0E79ZRIexdPdZ/category_food/american_hamburger.png"},"47fade86-5bd1-4789-87af-896fb1433a7b":{"name":"enemy2","sourceUrl":"assets/api/v1/animation-library/gamelab/dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG/category_food/american_pastrami.png","frameSize":{"x":355,"y":241},"frameCount":1,"looping":true,"frameDelay":2,"version":"dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":355,"y":241},"rootRelativePath":"assets/api/v1/animation-library/gamelab/dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG/category_food/american_pastrami.png"},"043deebf-64b8-4795-be8d-db5055414f2f":{"name":"enemy3","sourceUrl":"assets/api/v1/animation-library/gamelab/YSis4_lex43su6FLaL__bhoag4eHAl8D/category_food/american_bbqribs.png","frameSize":{"x":388,"y":388},"frameCount":1,"looping":true,"frameDelay":2,"version":"YSis4_lex43su6FLaL__bhoag4eHAl8D","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":388,"y":388},"rootRelativePath":"assets/api/v1/animation-library/gamelab/YSis4_lex43su6FLaL__bhoag4eHAl8D/category_food/american_bbqribs.png"},"c26b6449-0b6c-4483-8486-107c0091c26e":{"name":"hero1","sourceUrl":"assets/api/v1/animation-library/gamelab/loycQXdICpzI4PfXITdIndG9GcVBmRdK/category_faces/kidportrait_01.png","frameSize":{"x":264,"y":368},"frameCount":1,"looping":true,"frameDelay":2,"version":"loycQXdICpzI4PfXITdIndG9GcVBmRdK","categories":["faces"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":264,"y":368},"rootRelativePath":"assets/api/v1/animation-library/gamelab/loycQXdICpzI4PfXITdIndG9GcVBmRdK/category_faces/kidportrait_01.png"},"3221caad-ae37-4eec-92a8-56bae4769e66":{"name":"b","sourceUrl":"assets/api/v1/animation-library/gamelab/IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT/category_backgrounds/kitchen.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT/category_backgrounds/kitchen.png"},"c4e310e0-8174-4127-a46e-0cbcc94b488b":{"name":"dream","sourceUrl":null,"frameSize":{"x":386,"y":268},"frameCount":1,"looping":true,"frameDelay":12,"version":"6ZcqTirY403r9_sVmHKIJmeVD63p7K2x","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":386,"y":268},"rootRelativePath":"assets/c4e310e0-8174-4127-a46e-0cbcc94b488b.png"},"102dacfe-c65e-4395-8965-8956939facd7":{"name":"space_1","sourceUrl":"assets/api/v1/animation-library/gamelab/qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9/category_backgrounds/background_space.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9/category_backgrounds/background_space.png"},"70a55409-907a-431f-85ac-c9f61cf6397b":{"name":"ufo_02_1","sourceUrl":"assets/api/v1/animation-library/gamelab/QrXSuy9Lst0RVUF7O1QEbrfGQLjzvxzy/category_vehicles/ufo_02.png","frameSize":{"x":398,"y":332},"frameCount":1,"looping":true,"frameDelay":2,"version":"QrXSuy9Lst0RVUF7O1QEbrfGQLjzvxzy","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":398,"y":332},"rootRelativePath":"assets/api/v1/animation-library/gamelab/QrXSuy9Lst0RVUF7O1QEbrfGQLjzvxzy/category_vehicles/ufo_02.png"},"7552fbc5-56ad-42cc-b172-2b128f545c16":{"name":"playerShip1_blue_1","sourceUrl":"assets/api/v1/animation-library/gamelab/EFY9oqBBpFM5UwPvGD7JcFtTTIiVjD1./category_vehicles/playerShip1_blue.png","frameSize":{"x":99,"y":75},"frameCount":1,"looping":true,"frameDelay":2,"version":"EFY9oqBBpFM5UwPvGD7JcFtTTIiVjD1.","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":99,"y":75},"rootRelativePath":"assets/api/v1/animation-library/gamelab/EFY9oqBBpFM5UwPvGD7JcFtTTIiVjD1./category_vehicles/playerShip1_blue.png"},"2d207d44-84d0-42d2-b8a7-21ab2a1debd2":{"name":"ufoBlue_1","sourceUrl":"assets/api/v1/animation-library/gamelab/Mm_U04vWjYgiMntQGcHd1Zc680jjaRjJ/category_vehicles/ufoBlue.png","frameSize":{"x":91,"y":91},"frameCount":1,"looping":true,"frameDelay":2,"version":"Mm_U04vWjYgiMntQGcHd1Zc680jjaRjJ","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":91,"y":91},"rootRelativePath":"assets/api/v1/animation-library/gamelab/Mm_U04vWjYgiMntQGcHd1Zc680jjaRjJ/category_vehicles/ufoBlue.png"},"672779ce-0acc-4286-b18e-157ee8a14585":{"name":"playerShip3_blue_1","sourceUrl":null,"frameSize":{"x":98,"y":75},"frameCount":1,"looping":true,"frameDelay":1,"version":"8YVSrCo9Y.gHr8kd4rErwlR_R5DEAr8P","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":98,"y":75},"rootRelativePath":"assets/672779ce-0acc-4286-b18e-157ee8a14585.png"},"22d01de8-2028-4e2b-b9fd-39bd545b2a8e":{"name":"enemyBlue3_1","sourceUrl":"assets/api/v1/animation-library/gamelab/vBdsyxwhFjTALJN9ubK2KTLxPJ1.Zdzj/category_vehicles/enemyBlue3.png","frameSize":{"x":103,"y":84},"frameCount":1,"looping":true,"frameDelay":2,"version":"vBdsyxwhFjTALJN9ubK2KTLxPJ1.Zdzj","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":103,"y":84},"rootRelativePath":"assets/api/v1/animation-library/gamelab/vBdsyxwhFjTALJN9ubK2KTLxPJ1.Zdzj/category_vehicles/enemyBlue3.png"},"fd4e8157-ed28-495b-8dc7-89a185b599a4":{"name":"gameplayadventure_13_1","sourceUrl":"assets/api/v1/animation-library/gamelab/sgPdLrZdfJvLRM1OXBLfDNS9Ietk5ayX/category_video_games/gameplayadventure_13.png","frameSize":{"x":328,"y":399},"frameCount":1,"looping":true,"frameDelay":2,"version":"sgPdLrZdfJvLRM1OXBLfDNS9Ietk5ayX","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":328,"y":399},"rootRelativePath":"assets/api/v1/animation-library/gamelab/sgPdLrZdfJvLRM1OXBLfDNS9Ietk5ayX/category_video_games/gameplayadventure_13.png"},"05eb5005-059e-4051-811c-e667a53783bc":{"name":"wing_bot_1","sourceUrl":"assets/api/v1/animation-library/gamelab/8vku5_RNEZvo3XZVdvh4Olm1LbbiMIBb/category_fantasy/wing_bot.png","frameSize":{"x":218,"y":128},"frameCount":8,"looping":true,"frameDelay":2,"version":"8vku5_RNEZvo3XZVdvh4Olm1LbbiMIBb","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":1744,"y":128},"rootRelativePath":"assets/api/v1/animation-library/gamelab/8vku5_RNEZvo3XZVdvh4Olm1LbbiMIBb/category_fantasy/wing_bot.png"},"404d85ea-48c5-4058-a13e-be40ca758716":{"name":"gameplayadventure_02_1","sourceUrl":"assets/api/v1/animation-library/gamelab/on_n5nYApK0zhlPP5IRPqG168hwGRaeo/category_video_games/gameplayadventure_02.png","frameSize":{"x":359,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"on_n5nYApK0zhlPP5IRPqG168hwGRaeo","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":359,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/on_n5nYApK0zhlPP5IRPqG168hwGRaeo/category_video_games/gameplayadventure_02.png"},"9d52c37c-05c8-4604-8fb4-86158c49ceed":{"name":"gameplay_candy09_1","sourceUrl":"assets/api/v1/animation-library/gamelab/wYxbPiAyl4JNSzWrRw0hG8oCfqCHK8of/category_video_games/gameplay_candy09.png","frameSize":{"x":326,"y":398},"frameCount":1,"looping":true,"frameDelay":2,"version":"wYxbPiAyl4JNSzWrRw0hG8oCfqCHK8of","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":326,"y":398},"rootRelativePath":"assets/api/v1/animation-library/gamelab/wYxbPiAyl4JNSzWrRw0hG8oCfqCHK8of/category_video_games/gameplay_candy09.png"},"3cf76be0-ab3f-4f7f-82b4-c9c420b029db":{"name":"gameplay_candy02_1","sourceUrl":null,"frameSize":{"x":400,"y":476},"frameCount":1,"looping":true,"frameDelay":12,"version":"PGjXO6Hz.sz7VTCShhfP50UEmQ0.n8t7","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":476},"rootRelativePath":"assets/3cf76be0-ab3f-4f7f-82b4-c9c420b029db.png"},"e74f6250-bc30-4a10-a68b-7fa22987d7e4":{"name":"gameplay_candy02_2","sourceUrl":null,"frameSize":{"x":600,"y":714},"frameCount":1,"looping":true,"frameDelay":12,"version":"_Fph7G1vJuZWgI2R7s50WU1NK0FKdWsJ","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":600,"y":714},"rootRelativePath":"assets/e74f6250-bc30-4a10-a68b-7fa22987d7e4.png"},"9cd11998-6b06-4311-bab8-48140fca5ed6":{"name":"potion2_1","sourceUrl":"assets/api/v1/animation-library/gamelab/6ve3V43hN8WyYOc5TbP1nRlQAzP7r9uT/category_video_games/potion2.png","frameSize":{"x":244,"y":392},"frameCount":1,"looping":true,"frameDelay":2,"version":"6ve3V43hN8WyYOc5TbP1nRlQAzP7r9uT","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":244,"y":392},"rootRelativePath":"assets/api/v1/animation-library/gamelab/6ve3V43hN8WyYOc5TbP1nRlQAzP7r9uT/category_video_games/potion2.png"},"c6bbbdea-d7f7-43a0-bf3e-872b9bd46b56":{"name":"potion3_1","sourceUrl":"assets/api/v1/animation-library/gamelab/MoGacQwBELPXFxKw2IJBjw0rZE.BXGNG/category_video_games/potion3.png","frameSize":{"x":236,"y":391},"frameCount":1,"looping":true,"frameDelay":2,"version":"MoGacQwBELPXFxKw2IJBjw0rZE.BXGNG","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":236,"y":391},"rootRelativePath":"assets/api/v1/animation-library/gamelab/MoGacQwBELPXFxKw2IJBjw0rZE.BXGNG/category_video_games/potion3.png"},"ddb5fb82-9d7c-4f44-b92e-10659ab0e343":{"name":"powerupRed_bolt_1","sourceUrl":"assets/api/v1/animation-library/gamelab/_ULEwZxzC5zrDHSMDLExh683fOgrddy3/category_video_games/powerupRed_bolt.png","frameSize":{"x":34,"y":33},"frameCount":1,"looping":true,"frameDelay":2,"version":"_ULEwZxzC5zrDHSMDLExh683fOgrddy3","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":34,"y":33},"rootRelativePath":"assets/api/v1/animation-library/gamelab/_ULEwZxzC5zrDHSMDLExh683fOgrddy3/category_video_games/powerupRed_bolt.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----



var gameState = "serve";



var b = createSprite(200,200);
 b.setAnimation("space_1")
var hero = createSprite(200,345,200,345)
hero.shapeColor="red"

var enemy1 = createSprite(200,290,10,10)
enemy1.shapeColor="red"

var enemy2 = createSprite(200,210,10,10)
enemy2.shapeColor="red"

var enemy3 = createSprite(200,50,10,10)
enemy3.shapeColor="red"

var enemy4 = createSprite(200,150,10,10)
enemy2.shapeColor="red"


var net = createSprite(200,20,200,20)
net.shapeColor="red"
net.setAnimation("powerupRed_bolt_1");

var goal =0;
var death = 0

hero.setAnimation("wing_bot_1");
hero.scale=.2;
enemy1.setAnimation("ufo_02_1");
enemy1.scale=.1;
enemy2.setAnimation("ufo_02_1");
enemy2.scale=.1;
enemy3.setAnimation("ufo_02_1");
enemy3.scale=.1;
enemy4.setAnimation("ufo_02_1");
enemy4.scale=.1;

enemy1.setVelocity(-15,0);
enemy2.setVelocity(15,0);
enemy3.setVelocity(15,0);
enemy4.setVelocity(-15,0);


function draw() {
  
//plano de fundo(b);


if(hero.isTouching(enemy1)||
hero.isTouching(enemy2)||
hero.isTouching(enemy3) ||
hero.isTouching(enemy4)){
   gameState = "end";
}






createEdgeSprites()



hero.bounceOff(edges)
enemy1.bounceOff(edges)
enemy2.bounceOff(edges)
enemy3.bounceOff(edges)
enemy4.bounceOff(edges)
if(keyDown(UP_ARROW)){
  hero.y=hero.y-3
}

if(keyDown(DOWN_ARROW)){
  hero.y=hero.y+3
}

if(keyDown(LEFT_ARROW)){
  hero.x=hero.x-3
}

if(keyDown(RIGHT_ARROW)){
  hero.x=hero.x+3
}


if(hero.isTouching(enemy1)|| hero.isTouching(enemy2)|| hero.isTouching(enemy3) ||hero.isTouching(enemy4)){
  playSound("assets/category_achievements/bubbly_game_achievement_sound.mp3")
  hero.x=200
  hero.y=350
  death = death+1
}
if(hero.isTouching(net)){
  playSound("assets/category_achievements/vibrant_game_game_gold_tresure_chest_open.mp3")
  hero.x=200
  hero.y=345
  goal=goal+1
}
drawSprites();

textSize(20)
  fill("white")
  text("Objetivos:"+goal,320,350);
  

textSize(20)
  fill("white")
  text("mortes:"+death,20,350);
  
drawSprites()
}












// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
